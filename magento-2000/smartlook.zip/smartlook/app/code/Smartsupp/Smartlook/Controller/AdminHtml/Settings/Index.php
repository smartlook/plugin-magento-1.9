<?php

namespace Smartsupp\Smartlook\Controller\Adminhtml\Settings;

use Exception;
use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Smartlook\Webapi\Client;
use Smartsupp\Auth\Api;
use Smartsupp\Smartlook\Block\Adminhtml\SmartlookBlock;
use Smartsupp\Smartsupp\Block\Adminhtml\SmartsuppBlock;

/**
 * @author Tomáš Blatný
 */
class Index extends Action
{

	const DOMAIN = 'smartlook';
	const AUTH_KEY = '47a2435f1f3673ffce7385bc57bbe3e7353ab02e';
	const CONFIG_PATH = __DIR__ . '/../../../etc/config.json';

	/** @var PageFactory */
	private $pageFactory;


	/**
	 * @param Context $context
	 */
	public function __construct(Context $context)
	{
		parent::__construct($context);
		$this->pageFactory = $this->_objectManager->create('Magento\Framework\View\Result\PageFactory');
	}


	public function getStoreName()
	{
		return $this->_objectManager->create('\Magento\Store\Model\StoreManagerInterface')->getStore()->getName();
	}


	public function getLocale()
	{
		return $this->_objectManager->create('\Magento\Store\Api\Data\StoreInterface')->getLocaleCode();
	}


	public function execute()
	{
		$message = NULL;
		$formAction = NULL;

		if (isset($_GET['slaction'])) {
			switch ($_GET['slaction']) {
				case 'disable':
					$this->updateOptions(array(
						'email' => NULL,
						'chatId' => NULL,
						'chatKey' => NULL,
						'projectId' => NULL,
					));
					break;
				case 'login':
				case 'register':
					$api = new Client;
					$result = $_GET['slaction'] === 'register' ?
						$api->signUp(array('authKey' => self::AUTH_KEY, 'email' => $_POST['email'], 'password' => $_POST['password'], 'lang' => $this->convertLocale($this->getLocale()),)) :
						$api->signIn(array('authKey' => self::AUTH_KEY, 'email' => $_POST['email'], 'password' => $_POST['password'],));

					if ($result['ok']) {
						$projectId = NULL;
						$chatKey = NULL;
						if ($_GET['slaction'] === 'register') {
							$api->authenticate($result['account']['apiKey']);
							$project = $api->projectsCreate(array(
								'name' => $this->getStoreName(),
							));
							$projectId = $project['project']['id'];
							$chatKey = $project['project']['key'];
						} else {
							$api->authenticate($result['account']['apiKey']);
						}
						$this->updateOptions(array(
							'email' => $result['user']['email'],
							'chatId' => $result['account']['apiKey'],
							'chatKey' => $chatKey,
							'customCode' => '',
							'projectId' => $projectId,
						));
					} else {
						$message = $result['error'];
						$formAction = $_GET['slaction'] === 'register' ? NULL : 'login';
						$data['email'] = $_POST['email'];
					}

					break;
				case 'update':
					$api = new Client;
					$options = $this->getOptions();
					$api->authenticate($options['chatId']);
					$project = $_POST['project'];
					if (substr($project, 0, 1) === '_') {
						$project = $api->projectsCreate(array(
							'name' => substr($project, 1),
						));
					} else {
						$project = $api->projectsGet(array(
							'id' => $project,
						));
					}
					$this->updateOptions(array(
						'projectId' => $project['project']['id'],
						'chatKey' => $project['project']['key'],
					));
					break;
			}
		}

		$project = NULL;
		$projects = NULL;
		if ($chatId = $this->getOption('chatId')) {
			$api = new Client;
			$api->authenticate($chatId);
			$projects = $api->projectsList();
			$projects = $projects['projects'];
			if (count($projects) === 1) {
				$this->updateOptions(array('projectId' => $projects[0]['id'], 'chatKey' => $projects[0]['key']));
			}
			if ($projectId = $this->getOption('projectId')) {
				$project = $projectId;
			}
		}

		if ($message) {
			$mapping = array(
				'invalid_param' => $formAction ? 'Email not found.' : 'Email already registered.',
				'not_found' => $formAction ? 'Email not found.' : 'Email already registered.',
				'sign:invalid_password' => 'Invalid password.',
				'sign:login_failure' => 'Login failed, please try again.',
			);
			if (isset($mapping[$message])) {
				$message = $mapping[$message];
			} else {
				$message = ''; // better fail silently than display unknown message from API
			}
		}

		SmartlookBlock::setTemplateData(array(
			'domain' => self::DOMAIN,
			'options' => $this->getOptions(),
			'message' => (string) $message,
			'formAction' => $formAction,
			'email' => $email = $this->getOption('email', NULL),
			'enabled' => (bool) $email,
			'projects' => $projects,
			'project' => $project,
			'displayForm' => !$project,
		));

		$this->_view->loadLayout();
		$this->_view->renderLayout();
	}


	private function updateOptions(array $options)
	{
		$current = $this->getOptions();
		foreach ($options as $key => $option) {
			$current[$key] = $option;
		}
		file_put_contents(self::CONFIG_PATH, json_encode($current));
	}


	/**
	 * @return array
	 */
	private function getOptions()
	{
		$config = @file_get_contents(self::CONFIG_PATH);
		if (!$config) {
			$config = array();
		} else {
			$config = json_decode($config, JSON_OBJECT_AS_ARRAY);
		}
		return $config;
	}


	/**
	 * @param string $name
	 * @param mixed $default
	 * @return mixed
	 */
	private function getOption($name, $default = NULL)
	{
		$options = $this->getOptions();
		return isset($options[$name]) ? $options[$name] : $default;
	}


	private function convertLocale($locale)
	{
		$available = array('en', 'cs', 'da', 'nl', 'fr', 'de', 'hu', 'it', 'ja', 'pl', 'br', 'pt', 'es', 'tr', 'eu', 'cn', 'tw', 'ro', 'ru', 'sk');
		$part = strtolower(substr($locale, 0, 2));
		$locale = strtolower(substr($locale, 0, 5));
		if (!in_array($part, $available, TRUE)) {
			return 'en';
		}
		if ($part === 'pt') {
			if ($locale === 'pt_br') {
				$part = 'br';
			}
		} elseif ($part === 'zh') {
			if ($locale === 'zh_cn') {
				$part = 'cn';
			} elseif ($locale === 'zh_tw') {
				$part = 'tw';
			} else {
				$part = NULL;
			}
		} elseif ($part === 'eu') {
			$part = NULL;
		}
		return $part ?: 'en';
	}


}
