<?php

namespace Smartsupp\Smartlook\Block\Adminhtml;

use Magento\Backend\Block\Template;
use Magento\Framework\UrlInterface;

/**
 * @author Tomáš Blatný
 */
class SmartlookBlock extends Template
{

	/** @var string */
	private $baseUrl;

	/** @var array */
	private static $data;

	public function __construct(Template\Context $context, array $data = [])
	{
		parent::__construct($context, $data);
		$this->baseUrl = $this->_storeManager->getStore()->getBaseUrl(UrlInterface::URL_TYPE_MEDIA) . 'smartlook';
	}


	public function getBaseUrl()
	{
		return $this->baseUrl;
	}


	public static function setTemplateData(array $data)
	{
		self::$data = $data;
	}


	public function getTemplateData()
	{
		return self::$data;
	}

}
