<?php
/**
 * @author Tomáš Blatný
 */

use Magento\Framework\Component\ComponentRegistrar;

require_once __DIR__ . '/Auth/Client.php';

ComponentRegistrar::register(ComponentRegistrar::MODULE, 'Smartsupp_Smartlook', __DIR__);
